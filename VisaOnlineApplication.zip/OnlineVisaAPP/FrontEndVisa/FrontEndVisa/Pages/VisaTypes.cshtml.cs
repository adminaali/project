using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FrontEndVisa.Pages
{
    public class VisaModel : PageModel
    {
        public void OnGet()
        {

            //Model.VisaTypes = _visaService.GetVisaTypes();
        }
    }
}
