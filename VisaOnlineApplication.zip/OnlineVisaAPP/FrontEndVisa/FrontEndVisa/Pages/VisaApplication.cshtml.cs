using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FrontEndVisa.Pages
{
    public class VisaApplicationModel : PageModel
    {

        public int VisaApplicationId { get; set; }
        public int ApplicantId { get; set; }
        public int VisaType { get; set; }
       
        public int ApplicationStatus { get; set; }
     
        public void OnGet()
        {
               
        }
    }
}
