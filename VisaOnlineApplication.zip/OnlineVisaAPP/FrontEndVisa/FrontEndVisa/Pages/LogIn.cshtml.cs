using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FrontEndVisa.Pages
{
    public class LogInModel : PageModel
    {

        public string Email { get; set; }

        
        public string Password { get; set; }
        public void OnGet()
        {

        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
                return Page();

            // Process login logic and redirect
            // You can use a service to handle login logic
            // e.g., _visaService.Login(LoginDto);

            return RedirectToPage("/Index"); // Redirect to home page
        }
    }

}

