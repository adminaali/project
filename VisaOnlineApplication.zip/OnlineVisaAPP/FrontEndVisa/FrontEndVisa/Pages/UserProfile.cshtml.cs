using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FrontEndVisa.Pages
{
    public class UserProfileModel : PageModel
    {
        public void OnGet()
        {


        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
                return Page();

            // Process update profile logic and redirect
            // You can use a service to handle the update profile logic
            // e.g., _visaService.UpdateUserProfile(ApplicantDto);

            return RedirectToPage("/Index"); // Redirect to home page
        }

    }
}
