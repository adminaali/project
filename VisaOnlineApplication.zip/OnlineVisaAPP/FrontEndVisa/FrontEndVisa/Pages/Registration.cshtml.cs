using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FrontEndVisa.Pages
{
    public class RegistrationModel : PageModel
    {

        [BindProperty]
        
        public string FirstName { get; set; }

        
        public string Lastname { get; set; }
        
        public string Email { get; set; }

        
        public string Password { get; set; }
        public int Id { get; set; }


        public string PhoneNo { get; set; }
        public void OnGet()
        {


        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
                return Page();

            

            return RedirectToPage("/Index"); // Redirect to home page
        }
    }

}

