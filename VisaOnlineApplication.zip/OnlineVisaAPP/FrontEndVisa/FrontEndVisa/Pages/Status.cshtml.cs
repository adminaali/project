using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FrontEndVisa.Pages
{
    public class StatusModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
