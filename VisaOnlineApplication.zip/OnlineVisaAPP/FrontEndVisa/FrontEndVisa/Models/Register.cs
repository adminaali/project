﻿using System.ComponentModel.DataAnnotations;

namespace VisaApplication.Models
{
    public class Register
    {
        [Required(ErrorMessage = "Full Name is required")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Username is required")]
        public string Lastname { get; set; }
        [Required]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; }
        public int Id { get; set; }
       

        public string PhoneNo { get; set; }
       
       
        




    }
}
