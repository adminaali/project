﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlineApplicationVisa.Repository
{
    public class DocumentService:IDocumentService
    {
        private readonly VisaDbContext _context;

        public DocumentService(VisaDbContext context)
        {
            _context = context;
        }

        public void UploadDocument(DocumentDto documentDto)
        {
            var document = new Document
            {
               
            };

            _context.Documents.Add(document);
            _context.SaveChanges();
        }

    }

}
