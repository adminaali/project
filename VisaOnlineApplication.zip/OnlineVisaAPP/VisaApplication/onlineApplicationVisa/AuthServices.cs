﻿using onlineApplicationVisa.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlineApplicationVisa.Visa
{
    public class AuthServices
    {
        public class AuthService : IAuthService
        {
            private readonly VisaDbContext _context;

            public AuthService(VisaDbContext context)
            {
                _context = context;
            }

            public string Login(LoginDto loginDto)
            {
                // Implement login logic, e.g., validating credentials and generating a JWT token
                // For simplicity, let's assume a simple username/password check
                var isValidCredentials = _context.Email.Any(u => u.Email== loginDto.Email && u.Password == loginDto.Password);



            }
            if (!isValidCredentials)
            return null;

       
         }

        
    }

}
    
