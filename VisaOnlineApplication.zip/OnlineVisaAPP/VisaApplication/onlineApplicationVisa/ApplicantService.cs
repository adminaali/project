﻿using onlineApplicationVisa.Visa;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlineApplicationVisa
{
    public class ApplicantService : IApplicantService
    {
        private readonly VisaDbContext _context;

        public ApplicantService(VisaDbContext context)
        {
            _context = context;
        }

        public void RegisterApplicant(ApplicantDto applicantDto)
        {
            // Implement registration logic, e.g., mapping DTO to entity and saving to the database
            var applicant = new Applicant
            {
                FullName = applicantDto.FullName,
                // Map other properties
            };

            _context.Applicants.Add(applicant);
            _context.SaveChanges();
        }

        public Applicant GetApplicantInformation(int applicantId)
        {
            // Implement logic to retrieve applicant information from the database
            var applicant = _context.Applicants.FirstOrDefault(a => a.ApplicantId == applicantId);

            // Map entity to DTO
            var applicant = new Applicant
            {
                FullName = applicant.FullName,
                // Map other properties
            };

            return applicant;
        }

        // Implement other methods
    }

}
