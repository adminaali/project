﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlineApplicationVisa.Visa
{
    public class visaType
    {

        public string visaTypeid { get; set; }
        public string TypeName { get; set; }

    }
}
