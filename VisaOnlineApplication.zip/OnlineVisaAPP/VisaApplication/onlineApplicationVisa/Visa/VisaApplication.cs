﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlineApplicationVisa.Visa
{
    public class VisaApplication
    {

        public int Applicantid { get; set; }

        public String ApplicationStatus { get; set; }

        public int DocumentId { get; set; }

        public int visaApplicationId { get; set; }

        public string visaType { get; set; }




    }

}
