﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

using onlineApplicationVisa.Visa;


namespace onlineApplicationVisa
{
    public class VisaDbContext:DbContext
    {

        public VisaDbContext(DbContextOptions<VisaDbContext> options) : base(options) { }

        public DbSet<Applicant> Applicants { get; set; }
        public DbSet<visaType> VisaTypes { get; set; }
        public DbSet<VisaApplication> VisaApplications { get; set; } 

        public DbSet<ApplicationStatus> ApplicationStatuses { get; set; }
        public DbSet<Document> Documents { get; set; }

        public DbSet<Registration> Registers { get; set; }

        public DbSet<LogIn> LogInes { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            
            //optionsBuilder.UseSqlServer("Server=DESKTOP-J0RA0I8;Database=OnlineVisa;Trusted_Connection=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //use this to configure the model

            base.OnModelCreating(modelBuilder);


            //modelBuilder.Entity<VisaApplication>()
            //    .HasMany<VisaApplication>(p => p.VisaType)
            //    .WithOne()
            //    .IsRequired()
            //    .OnDelete(DeleteBehavior.Cascade);
        }






    }


   }
