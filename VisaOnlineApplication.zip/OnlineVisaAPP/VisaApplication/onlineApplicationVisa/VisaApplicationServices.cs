﻿using onlineApplicationVisa.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlineApplicationVisa
{
    public class VisaApplicationService:IVisaApplicationService
    {
        private readonly VisaDbContext _context;

        public VisaApplicationService(VisaDbContext context)
        {
            _context = context;
        }

        public void SubmitApplication(VisaApplication applicationDto)
        {
            
            var application = new VisaApplication
            {
                // Map properties from DTO to entity
            };

            _context.VisaApplications.Add(application);
            _context.SaveChanges();
        }

        
    }

}
