﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlineApplicationVisa.Repository
{
    public interface IVisaApplicationService
    {
        void SubmitApplication(VisaApplicationDto applicationDto);
        // Add other methods as needed
    }

}
