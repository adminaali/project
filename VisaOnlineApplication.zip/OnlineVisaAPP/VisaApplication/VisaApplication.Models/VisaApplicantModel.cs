﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace VisaApplication.Models
{
    public class VisaApplicantModel
    {
        private int visaapplicationid;

        public int VisaApplicationId
        {
            get { return visaapplicationid; }
            set { visaapplicationid = value; }
        }
        
        public int ApplicantId { get; set; }

        private int visatype;

        public int VisaType
        {
            get { return visatype; }
            set { visatype = value; }
        }
        
        public int DocumentId { get; set; }

        private int applicationstatus;

        public int ApplicationStatus
        {
            get { return applicationstatus; }
            set { applicationstatus = value; }
        }
        
        

        public int Applicant { get; set; }
    }
}
