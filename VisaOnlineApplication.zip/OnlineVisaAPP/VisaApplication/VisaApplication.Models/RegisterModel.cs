﻿

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace VisaApplication.Models
{
    public class RegisterModel
    {
        [Required]
        private string firstname;

        public string FirstName
        {
            get { return firstname; }
            set { firstname = value; }
        }

        private string lastname;

        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }
        [Required]
        private string email;

        public string Email
        {
            get { return email; }
            set { email = value; }
        }




        
        [Required]
        public string Password { get; set; }

        private int id;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
       
       

        public string PhoneNo { get; set; }
       
       
        




    }
}
