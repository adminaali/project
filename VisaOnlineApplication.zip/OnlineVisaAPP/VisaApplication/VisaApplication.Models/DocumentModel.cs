﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace VisaApplication.Models
{
    public class DocumentModel
    {

        public int DocumentId { get; set; }
        public string DocumentName { get; set; }
    }
}
