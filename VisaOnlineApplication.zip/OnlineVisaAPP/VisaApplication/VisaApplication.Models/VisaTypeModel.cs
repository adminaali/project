﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace VisaApplication.Models
{
    public class VisaTypeModel
    {
        private int visatypeid;

        public int VisaTypeId
        {
            get { return visatypeid; }
            set { visatypeid = value; }
        }

        
        public string TypeName { get; set; }
    }
}
