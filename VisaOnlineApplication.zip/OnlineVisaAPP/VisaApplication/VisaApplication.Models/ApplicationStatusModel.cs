﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace VisaApplication.Models
{
    public class ApplicationStatusModel
    {

        private int applicationstatusid;

        public int ApplicationStatusId
        {
            get { return applicationstatusid; }
            set { applicationstatusid = value; }
        }
        
        public string StatusName { get; set; }
    }
}
