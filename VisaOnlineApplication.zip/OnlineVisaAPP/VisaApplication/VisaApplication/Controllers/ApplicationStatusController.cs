﻿using Microsoft.AspNetCore.Mvc;

namespace VisaServiceAPI.Controllers
{

    [ApiController]
    [Route("api/applicationstatus")]

    public class ApplicationStatusController : Controller
    {

        private readonly IApplicationStatusService _applicationStatusService;

        public ApplicationStatusController(IApplicationStatusService applicationStatusService)
        {
            _applicationStatusService = applicationStatusService;
        }

        [HttpGet("{applicationId}")]
        public IActionResult GetApplicationStatus(int applicationId)
        {
            try
            {
                var status = _applicationStatusService.GetApplicationStatus(applicationId);
                return Ok(status);
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, "Internal server error");
            }
        }


    }
}
