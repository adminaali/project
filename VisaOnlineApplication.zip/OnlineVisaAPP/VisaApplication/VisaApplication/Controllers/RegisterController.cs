﻿using Microsoft.AspNetCore.Mvc;
using onlineApplicationVisa;
using System.Security.Claims;
using System.Text;


namespace VisaApplication.Controllers
{
    [ApiController]
    [Route("api/register")]
    public class RegisterController : Controller
    {

        private readonly IApplicantService _applicantService;

        public ApplicantsController(IApplicantService applicantService)
        {
            _applicantService = applicantService;
        }

        [HttpPost]
        public IActionResult RegisterApplicant([FromBody]ApplicantDto applicantDto)
        {
            try
            {
                _applicantService.RegisterApplicant(applicantDto);
                return Ok("Applicant registered successfully");
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, "Internal server error");
            }
        }




    }
}
