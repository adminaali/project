﻿using Microsoft.AspNetCore.Mvc;

namespace VisaServiceAPI.Controllers
{
    [ApiController]
    [Route("api/documents")]

    public class DocumentController : Controller
    {
        private readonly IDocumentService _documentService;

        public DocumentsController(IDocumentService documentService)
        {
            _documentService = documentService;
        }

        [HttpPost]
        public IActionResult UploadDocument([FromBody] DocumentDto documentDto)
        {
            try
            {
                _documentService.UploadDocument(documentDto);
                return Ok("Document uploaded successfully");
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, "Internal server error");
            }
        }



    }
}
