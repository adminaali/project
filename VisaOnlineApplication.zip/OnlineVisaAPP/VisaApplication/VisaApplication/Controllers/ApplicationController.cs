﻿using Microsoft.AspNetCore.Mvc;

namespace VisaServiceAPI.Controllers
{

    [ApiController]
    [Route("api/application")]

    public class ApplicationController : Controller
    {
        private readonly IApplicantService _applicantService;

        public ApplicantController(IApplicantService applicantService)
        {
            _applicantService = applicantService;
        }

        [HttpGet("{applicantId}")]
        public IActionResult GetApplicantInformation(int applicantId)
        {
            try
            {
                var applicantInfo = _applicantService.GetApplicantInformation(applicantId);
                return Ok(applicantInfo);
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, "Internal server error");
            }
        }


    }
}
