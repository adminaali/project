﻿using Microsoft.AspNetCore.Mvc;

namespace VisaServiceAPI.Controllers
{

    [ApiController]
    [Route("api/auth")]

    public class LogInController : Controller
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("login")]
        public IActionResult Login(string Email, string password, loginDto)
        {
            try
            {
                var token = _authService.Login(loginDto);
                if (token == null)
                    return Unauthorized("Invalid credentials");

                return Ok(new { Token = token });
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, "Internal server error");
            }

        }
    }
}
