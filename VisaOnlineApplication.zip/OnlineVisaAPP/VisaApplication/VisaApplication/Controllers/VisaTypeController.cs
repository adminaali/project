﻿using Microsoft.AspNetCore.Mvc;

namespace VisaServiceAPI.Controllers
{

    [ApiController]
    [Route("api/visatypes")]

    public class VisaTypeController : Controller
    {
        private readonly IVisaTypeService _visaTypeService;

        public VisaTypesController(IVisaTypeService visaTypeService)
        {
            _visaTypeService = visaTypeService;
        }

        [HttpGet]
        public IActionResult GetVisaTypes()
        {
            try
            {
                var visaTypes = _visaTypeService.GetVisaTypes();
                return Ok(visaTypes);
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, "Internal server error");
            }

        }
    }
}
