﻿using Microsoft.AspNetCore.Mvc;

namespace VisaServiceAPI.Controllers
{

    [ApiController]
    [Route("api/applications")]

    public class VisaApplicationController : Controller
    {

        private readonly IVisaApplicationService _visaApplicationService;

        public VisaApplicationController(IVisaApplicationService visaApplicationService)
        {
            _visaApplicationService = visaApplicationService;
        }

        [HttpPost]
        public IActionResult SubmitVisaApplication([FromBody] VisaApplicationDto applicationDto)
        {
            try
            {
                _visaApplicationService.SubmitApplication(applicationDto);
                return Ok("Visa application submitted successfully");
            }
            catch (Exception ex)
            {
                // Log the exception
                return StatusCode(500, "Internal server error");
            }
        }
    }


}

 